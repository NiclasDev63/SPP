#pragma once

#define AUTHORS_ONE_A ""
#define AUTHORS_ONE_B ""
#define AUTHORS_ONE_C ""
#define AUTHORS_ONE_D ""
#define AUTHORS_ONE_E ""
#define AUTHORS_ONE_F ""

#define AUTHORS_TWO_A ""
#define AUTHORS_TWO_B ""

#define AUTHORS_THREE_A ""
#define AUTHORS_THREE_B ""
