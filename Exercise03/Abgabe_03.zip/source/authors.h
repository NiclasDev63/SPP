#pragma once

#define AUTHORS_ONE_A "Jinxian Che, Lukas Horn, Niclas Gregor"
#define AUTHORS_ONE_B "Jinxian Che, Lukas Horn, Niclas Gregor"
#define AUTHORS_ONE_C "Jinxian Che, Lukas Horn, Niclas Gregor"
#define AUTHORS_ONE_D "Jinxian Che, Lukas Horn, Niclas Gregor"

#define AUTHORS_TWO_A "Jinxian Che, Lukas Horn, Niclas Gregor"
#define AUTHORS_TWO_B "Jinxian Che, Lukas Horn, Niclas Gregor"
#define AUTHORS_TWO_C "Jinxian Che, Lukas Horn, Niclas Gregor"

#define AUTHORS_THREE_A "Jinxian Che, Lukas Horn, Niclas Gregor"
#define AUTHORS_THREE_B "Jinxian Che, Lukas Horn, Niclas Gregor"
#define AUTHORS_THREE_C "Jinxian Che, Lukas Horn, Niclas Gregor"
#define AUTHORS_THREE_D "Jinxian Che, Lukas Horn, Niclas Gregor"
#define AUTHORS_THREE_E "Jinxian Che, Lukas Horn, Niclas Gregor"