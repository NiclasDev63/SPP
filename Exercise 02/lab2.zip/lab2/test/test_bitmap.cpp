#include "test.h"

#include "image/bitmap_image.h"

class BitmapTest : public LabTest {};

TEST_F(BitmapTest, test_one_b_one) {
}
