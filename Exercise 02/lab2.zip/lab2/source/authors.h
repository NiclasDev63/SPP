#pragma once

#define AUTHORS_ONE_A ""
#define AUTHORS_ONE_B ""

#define AUTHORS_TWO_A ""
#define AUTHORS_TWO_B ""
#define AUTHORS_TWO_C ""
#define AUTHORS_TWO_D ""
#define AUTHORS_TWO_E ""
#define AUTHORS_TWO_F ""

#define AUTHORS_THREE_A ""
#define AUTHORS_THREE_B ""
#define AUTHORS_THREE_C ""
#define AUTHORS_THREE_D ""
#define AUTHORS_THREE_E ""
#define AUTHORS_THREE_F ""